x = "cat"
y = "dog"
z = "pig"
x, y, z = y, z, x
print("x = ",x, "\ny = ", y, "\nz = ", z)
